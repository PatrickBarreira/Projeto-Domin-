//DOM-PJA- Projeto Domino - Etapa 5
//14/09/2023
//GRUPO: PJA
//Patrick Barreira, Joao Sieiro, Arthur Oliveira
#ifndef VIEW_H
#define VIEW_H
void limpaTela(); // Funcao de espacamento no console
void mostrarMesa(); // Funcao que mostra o estado atual da mes
void apresentaMensagem(char[100]); // Funcao que mostra uma string no console
void jogarRodada(int eIA); // Funcao para jogar a vez de um jogador, recebe como parametro um indicador se e a vez de um player ou de uma maquina
int mostrarMenuInicial(); // Funcao para mostrar o menu inicial do programa
#endif
