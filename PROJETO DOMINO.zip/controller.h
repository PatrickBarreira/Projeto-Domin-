//DOM-PJA- Projeto Domino - Etapa 5
//14/09/2023
//GRUPO: PJA
//Patrick Barreira, Joao Sieiro, Arthur Oliveira
#ifndef CONTROLLER_H
#define CONTROLLER_H
void pausarPorTempo(int segundos); // Funcao que pausa a execucao do console por alguns segundos
void inicializarPecasDoJogo(); // Funcao que inicializa as pecas do jogo
void comprarPecasParaJogador(int quantidade); // Funcao que permite o jogador atual comprar uma quantidade de pecas
void inicializarMaoDoJogador(); // Funcao que inicializa a mao do jogador atual com 7 pecas
int jogarPecaNoJogo(tipoPeca peca, int indicePeca); // Funcao que tenta fazer o jogador atual jogar uma peca, retornando 1 se for bem-sucedida e 0 caso contrario
void determinarPrimeiraJogada(); // Funcao que decide qual dos dois jogadores tem a maior dupla, faz a jogada inicial e informa o outro jogador, passando a vez
void salvarEstadoDoJogo(); // Funcao que salva o estado atual do jogo
void carregarEstadoDoJogo(); // Funcao que carrega um estado de jogo previamente salvo e continua a partida
void verificarVencedor(); // Funcao que verifica se ha um vencedor na partida
void jogarPartida(); // Funcao que inicia o loop principal para jogar uma partida
#endif
