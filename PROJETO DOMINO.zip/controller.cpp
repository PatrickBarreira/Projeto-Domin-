//DOM-PJA- Projeto Domino - Etapa 5
//14/09/2023
//GRUPO: PJA
//Patrick Barreira, Joao Sieiro, Arthur Oliveira
#include <time.h>
#include <stdlib.h>
#include "controller.h"
#include "view.h"
#include <string.h>
#include <stdio.h>

void pausarPorTempo(int segundos){
    time_t lt1 /* Tempo atual 1 */, lt2 /* Tempo atual 2*/;
    lt1 = time(NULL);
    lt2 = lt1;
    while(difftime(lt2,lt1) < segundos){
        lt2 = time(NULL); //tempo 2 vira o tempo atual
    } //Enquanto a diferen�a entre tempo 1 e tempo 2 n�o for maior que x segundos...
} // Fun��o que pausa a execu��o do console por alguns segundos
void inicializarPecasDoJogo(){
  int m=0;
  for(int i=0;i<=6;i++){// <-----------teste
    for(int j=i;j<=6;j++){// <-----------teste
        pecaAuxiliar.lado1 = i;
        pecaAuxiliar.lado2 = j;
        pecasDisponiveis[m] = pecaAuxiliar;  // Adiciona pe�a criada ao vetor de pe�as dispon�veis
      m++;
    }
  } // La�o para percorrer todas as combina��es de pe�as de domin� sem repeti��o
}  // Fun��o que inicializa as pe�as do jogo
void comprarPecasParaJogador(int quantidade) {
    for(int i=0; i < quantidade; i++){ // <-----------
        srand(time(NULL));
        int indexPecaComprada = rand() % totalPecasDisponiveis; // Gerar um n�mero aleat�rio menor que o total dispon�vel
        tipoPeca pecaComprada = pecasDisponiveis[indexPecaComprada]; //Usa um n�mero aleat�rio como �ndice para a pe�a comprada
        for(int j = indexPecaComprada; j<27; j++){ // <-----------
            pecaAuxiliar = pecasDisponiveis[j];
            pecasDisponiveis[j] = pecasDisponiveis[j + 1]; // <-----------
            pecasDisponiveis[j + 1] = pecaAuxiliar;
        } // Diminui o vetor de pe�as dispon�veis em 1 e passa todas as pe�as um �ndice depois da comprada para um �ndice para � esquerda
        jogadores[jogadorAtual].pecas[jogadores[jogadorAtual].qtdPecasMao] = pecaComprada;
        jogadores[jogadorAtual].qtdPecasMao++; // Adiciona a pe�a comprada ao vetor de pe�as do jogador e aumenta a quantidade
        totalPecasDisponiveis--;
    }
} // Fun��o que permite o jogador atual comprar uma quantidade de pe�as
void inicializarMaoDoJogador() {
    comprarPecasParaJogador(7);
} // Fun��o que inicializa a m�o do jogador atual com 7 pe�as
int jogarPecaNoJogo(tipoPeca peca, int indicePeca) {
    if(pecasJogadas == 0){
        pecasNoTabuleiro[pecasJogadas] = peca;
        pecasJogadas++;
        for(int i = indicePeca; i<jogadores[jogadorAtual].qtdPecasMao; i++){
            pecaAuxiliar = jogadores[jogadorAtual].pecas[i];
            jogadores[jogadorAtual].pecas[i] = jogadores[jogadorAtual].pecas[i+1];// <-----------
            jogadores[jogadorAtual].pecas[i+1] = pecaAuxiliar;// <-----------
        }
        jogadores[jogadorAtual].qtdPecasMao--;
        return 1;
    } // Se a fun��o foi chamada e n�o h� pe�as em campo ent�o � s� jogar a pe�a
    if(numeroEsquerdaTabuleiro == peca.lado1 || numeroDireitaTabuleiro == peca.lado2) {
        int temp = peca.lado1;
        peca.lado1 = peca.lado2;
        peca.lado2 = temp;
    } // Inverter os n�meros da pe�a a ser jogada
    if(numeroDireitaTabuleiro == peca.lado1){
        for(int i = indicePeca; i<jogadores[jogadorAtual].qtdPecasMao; i++){
            pecaAuxiliar = jogadores[jogadorAtual].pecas[i];
            jogadores[jogadorAtual].pecas[i] = jogadores[jogadorAtual].pecas[i+1];// <-----------
            jogadores[jogadorAtual].pecas[i+1] = pecaAuxiliar;// <-----------
        }
        jogadores[jogadorAtual].qtdPecasMao--;
        pecasNoTabuleiro[pecasJogadas].lado1 = peca.lado1;
        pecasNoTabuleiro[pecasJogadas].lado2 = peca.lado2;
        pecasJogadas++;
        char msg[100];
        sprintf(msg, "O jogador %d jogou a peca [%d|%d]!", jogadorAtual, peca.lado1, peca.lado2);
        apresentaMensagem(msg);
        pausarPorTempo(2);
        return 1;
    }
    if(numeroEsquerdaTabuleiro == peca.lado2){
        for(int i = pecasJogadas; i > 0;i--) {
            pecasNoTabuleiro[i] = pecasNoTabuleiro[i - 1];// <-----------
        }
        pecasJogadas++;
        for(int i = indicePeca; i<jogadores[jogadorAtual].qtdPecasMao; i++){
            pecaAuxiliar = jogadores[jogadorAtual].pecas[i];
            jogadores[jogadorAtual].pecas[i] = jogadores[jogadorAtual].pecas[i+1];// <-----------
            jogadores[jogadorAtual].pecas[i+1] = pecaAuxiliar;// <-----------
        }
        jogadores[jogadorAtual].qtdPecasMao--;
        pecasNoTabuleiro[0].lado1 = peca.lado1;
        pecasNoTabuleiro[0].lado2 = peca.lado2;
        char msg[100];
        sprintf(msg, "O jogador %d jogou a peca [%d|%d]!", jogadorAtual, peca.lado1, peca.lado2);
        apresentaMensagem(msg);
        pausarPorTempo(2);
        return 1;
    }
    return 0;
}
void determinarPrimeiraJogada(){
    int indiceMaiorPeca[2];
    tipoPeca maiorPeca[2];
    for(int j = 0; j<2;j++){// <-----------
        maiorPeca[j].lado1 = -1;// <-----------
        for(int i = 0; i<7;i++){
            if(jogadores[j].pecas[i].lado1 == jogadores[j].pecas[i].lado2 && jogadores[j].pecas[i].lado1 > maiorPeca[j].lado1){
                maiorPeca[j] = jogadores[j].pecas[i];
                indiceMaiorPeca[j] = i;
            }
        }
    }
    char msg[100];
    if(maiorPeca[0].lado1 > maiorPeca[1].lado1){
        jogadorAtual = 0;
        jogarPecaNoJogo(jogadores[0].pecas[indiceMaiorPeca[0]], indiceMaiorPeca[0]);
        sprintf(msg, "O jogador 0 tinha a peca [%d|%d] que e a dupla mais alta!, por tanto, ele comecou jogando e agora e a vez do jogador 1!", maiorPeca[0].lado1, maiorPeca[0].lado2);
        apresentaMensagem(msg);
        pausarPorTempo(2);
        jogadorAtual = 1;
    }
    else{
        jogarPecaNoJogo(jogadores[1].pecas[indiceMaiorPeca[1]], indiceMaiorPeca[1]);
        sprintf(msg, "O jogador 1 tinha a peca [%d|%d] que e a dupla mais alta!, por tanto, ele comecou jogando e agora e a vez do jogador 0!", maiorPeca[1].lado1, maiorPeca[1].lado2);
        apresentaMensagem(msg);
        pausarPorTempo(2);
        jogadorAtual = 0;
    }
}
void salvarEstadoDoJogo(){
    FILE *file = fopen("variaveis.txt", "wb");
    variaveis.modo = jogoSinglePlayer;
    variaveis.qtdPecasNaMesa = totalPecasDisponiveis;
    variaveis.pecasJogadas = pecasJogadas;
    variaveis.jogadorVencedor = jogadorVencedor;
    variaveis.jogadorAtual = jogadorAtual;
    variaveis.numEmesa = numeroEsquerdaTabuleiro;
    variaveis.numDmesa = numeroDireitaTabuleiro;
    memcpy(variaveis.mesa, pecasDisponiveis, sizeof(structPeca) * 28);
    memcpy(variaveis.mesaAtual, pecasNoTabuleiro, sizeof(structPeca) * 28);
    variaveis.aux = pecaAuxiliar;
    memcpy(variaveis.jogadores, jogadores, sizeof(structJogador) * 2);
    fwrite(&variaveis, sizeof(variaveisJogo), 1, file);
    fclose(file);
}
void carregarEstadoDoJogo(){
    FILE *file = fopen("variaveis.txt", "rb");
    fread(&variaveis, sizeof(variaveisJogo), 1, file);
    jogoSinglePlayer = variaveis.modo;
    totalPecasDisponiveis = variaveis.qtdPecasNaMesa;
    pecasJogadas = variaveis.pecasJogadas;
    jogadorVencedor = variaveis.jogadorVencedor;
    jogadorAtual = variaveis.jogadorAtual;
    numeroEsquerdaTabuleiro = variaveis.numEmesa;
    numeroDireitaTabuleiro = variaveis.numDmesa;
    memcpy(pecasDisponiveis, variaveis.mesa, sizeof(structPeca) * 28);
    memcpy(pecasNoTabuleiro, variaveis.mesaAtual, sizeof(structPeca) * 28);
    pecaAuxiliar = variaveis.aux;
    memcpy(jogadores, variaveis.jogadores, sizeof(structJogador)*2);
    jogarPartida();
}
void verificarVencedor(){
    if(jogadores[0].qtdPecasMao == 0){
        jogadorVencedor = 0;
    }
    else if (jogadores[1].qtdPecasMao == 0){
        jogadorVencedor = 1;
    }
}
int checarPecaAJogar(){
    for(int i = 0; i < jogadores[jogadorAtual].qtdPecasMao; i++) {
        if (numeroEsquerdaTabuleiro == jogadores[jogadorAtual].pecas[i].lado1 || numeroEsquerdaTabuleiro == jogadores[jogadorAtual].pecas[i].lado2 ||
            numeroDireitaTabuleiro == jogadores[jogadorAtual].pecas[i].lado1 || numeroDireitaTabuleiro == jogadores[jogadorAtual].pecas[i].lado2) {
            return i;
        }
    }
    return -1;
}
void jogarPartida() {
    while (jogadorVencedor == -1){
        verificarVencedor();
        numeroEsquerdaTabuleiro = pecasNoTabuleiro[0].lado1;
        numeroDireitaTabuleiro = pecasNoTabuleiro[pecasJogadas - 1].lado2;
        if(jogoSinglePlayer == 1){
            if(jogadorAtual==0){
                jogarRodada(0);
                jogadorAtual++;
            }
            else{
                jogarRodada(1);
                jogadorAtual = 0;
            }
        }
        else{
            jogarRodada(0);
            jogadorAtual++;
            if (jogadorAtual>1){
                jogadorAtual = 0;
            }
        }
    }
    char msg[100];
    sprintf(msg, "O jogador %d foi o vencedor!", jogadorVencedor);
    apresentaMensagem(msg);
}
