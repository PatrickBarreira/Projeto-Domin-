//DOM-PJA- Projeto Domino - Etapa 5
//14/09/2023
//GRUPO: PJA
//Patrick Barreira, Joao Sieiro, Arthur Oliveira
#include "model.h"
int totalPecasDisponiveis = 28; // Total de pecas disponiveis para compra
int pecasJogadas = 0; // Quantidade de pecas ja� jogadas
int jogadorVencedor = -1; // O indice do jogador vencedor (-1 indica nao haver vencedor)
int jogadorAtual = 0; // O�indice do jogador atual no vetor de jogadores
int jogoSinglePlayer = 0; // Indica se o jogo e single player (0 para nao, 1 para sim)
int numeroEsquerdaTabuleiro = 0; // Numero mais a� esquerda no tabuleiro
int numeroDireitaTabuleiro = 0; // Numero mais a� direita no tabuleiro
tipoPeca pecasDisponiveis[28]; // Array que armazena as pecas disponiveis para compra
tipoPeca pecasNoTabuleiro[28]; // Array que armazena as pecas no campo de jogo
tipoPeca pecaAuxiliar; // Variável auxiliar que armazena uma pecas temporariamente
tipoJogador jogadores[2]; // Vetor com os jogadores do jogo (assumindo que o jogo suporta no maximo 2 jogadores)
variaveisJogo variaveis; // Struct que contam todas as variaveis do programa para fins de salvamento e carregamento
