//DOM-PJA- Projeto Domino - Etapa 5
//14/09/2023
//GRUPO: PJA
//Patrick Barreira, Joao Sieiro, Arthur Oliveira
#include <cstdio>
#include "view.h"
void limpaTela() {
  printf("\n\n\n");
} // Funcao para limpar o console
void mostrarMesa() {
  printf("\tMESA ATUAL:\t\n");
  for (int i = 0; i < pecasJogadas; i++) {
    printf(" [%d|%d] ", pecasNoTabuleiro[i].lado1, pecasNoTabuleiro[i].lado2);
  }
    printf("\n");
} // Funcao para exibir o estado atual da mesa
void apresentaMensagem(char mensagem[100]){
    printf("%s\n", mensagem);
} // Funcaoo para exibir uma mensagem no console
void jogarRodada(int eIA) {
    int indicePeca, opcaoJogador;
    if (eIA == 1){
        int indicePecaJogavel = checarPecaAJogar();
        while(indicePecaJogavel == -1){
            if(totalPecasDisponiveis > 0){
                comprarPecasParaJogador(1);
                printf("O oponente comprou uma peca...");
                indicePecaJogavel = checarPecaAJogar();
            }
            else{
                return;
            }
        }
        jogarPecaNoJogo(jogadores[jogadorAtual].pecas[indicePecaJogavel], indicePecaJogavel);
        return;
    }
    while(true){
        limpaTela();
        mostrarMesa();
        printf("\tJogador %d\n", jogadorAtual);
        printf("Mao:\n");
        for(int i = 0;i < jogadores[jogadorAtual].qtdPecasMao;i++){
            printf("%d: [%d|%d] ", i, jogadores[jogadorAtual].pecas[i].lado1, jogadores[jogadorAtual].pecas[i].lado2);
        }
        printf("\n");
        int iOponente;
        if (jogadorAtual == 1){
            iOponente = 0;
        }
        else{
            iOponente = 1;
        }
        printf("1 - Jogar (%d ou %d)\n2 - Comprar (Pecas no monte: %d)\n3 - Passar (Tamanho da mao do oponente: %d)\n4 - Salvar Jogo\nDigite a opcao desejada:", numeroEsquerdaTabuleiro, numeroDireitaTabuleiro, totalPecasDisponiveis, jogadores[iOponente].qtdPecasMao);
        scanf("%d", &opcaoJogador);
        switch(opcaoJogador){
            case  1:{
                printf("Digite o ID da peca que voce quer jogar: ");
                scanf("%d", &indicePeca);
                if(jogarPecaNoJogo(jogadores[jogadorAtual].pecas[indicePeca], indicePeca) == 1){
                    return;
                }
                else{
                    printf("A jogada digitada e invalida!");
                }
                break;
            }
            case  2:{
                if(totalPecasDisponiveis <= 0){
                    printf("Nao ha pecas na pilha de compras!");
                }
                else{
                    comprarPecasParaJogador(1);
                }
                break;
            }
            case  3:{
                if(totalPecasDisponiveis > 0 || checarPecaAJogar() != -1){
                    printf("Voce so pode passar a vez caso nao seja possivel realizar nenhuma outra acao!");
                }
                break;
            }
            case  4: {
                salvarEstadoDoJogo();
                break;
            }
            default :{
                printf("Escolha uma opcao valida!\n");
            }
        }
        limpaTela();
    }
} // Funcao para realizar a jogada de um jogador, recebe um indicador se e a vez de um jogador humano ou de uma maquina
int mostrarMenuInicial() {
    printf("===============================================\n");
    printf("1 - Iniciar jogo (2 Jogadores)\n");
    printf("2 - Iniciar jogo (Contra o computador)\n");
    printf("3 - Regras Gerais\n");
    printf("4 - Recuperar jogo salvo\n");
    printf("0 - Sair\n");
    int operacao;
    scanf("%d", &operacao);
    switch(operacao){
        case 1:{
            jogoSinglePlayer = 0;
            inicializarPecasDoJogo();
            inicializarMaoDoJogador();
            jogadorAtual++;
            inicializarMaoDoJogador();
            determinarPrimeiraJogada();
            jogarPartida();
            return 1;
        }
        case 2:{
            jogoSinglePlayer = 1;
            inicializarPecasDoJogo();
            inicializarMaoDoJogador();
            jogadorAtual++;
            inicializarMaoDoJogador();
            determinarPrimeiraJogada();
            jogarPartida();
            return 1;
        }
        case 3:{
            printf("Regras do Jogo de Domino Resumidas:\n1. Cada jogador comeca com sete pecas aleatorias.\n2. Inicia-se com o jogador que tiver a peca 'seis-seis' ou numeros repetidos mais altos.\n3. O jogo ocorre no sentido anti-horario.\n4. Coloque pecas que correspondam aos numeros nas pontas.\n5. Compre pecas antes de jogar, se necessario, mas evite acumula-las.\n6. Se nao puder jogar, compre pecas ou passe o turno.\n7. Vence quem colocar sua ultima peca ou, em impasse, quem tiver menos pecas ou pontos.\n\n");
            return 0;
        }
        case 4: {
            carregarEstadoDoJogo();
            return 1;
        }
        case 0:{
            printf("Obrigado por usar nosso programa!");
            return 1;
        }
        default:{
            printf("Digite uma opcao valida!\n");
            pausarPorTempo(2);
            return 0;
        }
    }
} // Funcao para exibir o menu inicial do programa
