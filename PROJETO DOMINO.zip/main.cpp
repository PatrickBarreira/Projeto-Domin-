//DOM-PJA- Projeto Domino - Etapa 1
//14/09/2023
//GRUPO: PJA
//Patrick Barreira, Joao Sieiro, Arthur Oliveira
#include "model.cpp"
#include "controller.cpp"
#include "view.cpp"

int main(){
  printf("\tProjeto [D|O] [M|I] [N|O]\n");
  printf("Patrick Barreira, Joao Sieiro, Arthur Oliveira\n");
  while(mostrarMenuInicial() == 0){
    mostrarMenuInicial();
  }
}
