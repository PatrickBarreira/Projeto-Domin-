//DOM-PJA- Projeto Domino - Etapa 5
//14/09/2023
//GRUPO: PJA
//Patrick Barreira, Joao Sieiro, Arthur Oliveira
#ifndef MODEL_H
#define MODEL_H
typedef struct structPeca {
    int lado1;
    int lado2;
} tipoPeca;
typedef struct structJogador{
    struct structPeca pecas[21];
    int qtdPecasMao;
} tipoJogador;
extern int totalPecasDisponiveis;
extern int jogoSinglePlayer;
extern int pecasJogadas;
extern int jogadorVencedor;
extern int jogadorAtual;
extern int numeroEsquerdaTabuleiro;
extern int numeroDireitaTabuleiro;
extern tipoPeca pecasDisponiveis[28];
extern tipoPeca pecasNoTabuleiro[28];
extern tipoPeca pecaAuxiliar;
extern tipoJogador jogadores[2];
typedef struct structVariaveis {
    int modo;
    int qtdPecasNaMesa;
    int pecasJogadas;
    int jogadorVencedor;
    int jogadorAtual;
    int numEmesa;
    int numDmesa;
    structPeca mesa[28];
    structPeca mesaAtual[28];
    tipoPeca aux;
    structJogador jogadores[2];
} variaveisJogo;
extern variaveisJogo variaveis;
#endif